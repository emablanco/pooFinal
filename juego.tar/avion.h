#ifndef AVION_H
#define AVION_H

#include "nave.h"
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Rect.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Text.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/System/Vector2.hpp>
#include <SFML/Window/Keyboard.hpp>
#include <string>

class Avion : public Nave {
private:
  sf::Sprite *ima_spr = nullptr;
  sf::Texture *ima_tex = nullptr;
  sf::IntRect rectangulo;
  sf::Vector2f escalarImagen;
  std::string ruta;
  sf::Vector2f posicion;
  sf::Vector2f velocidad;
  bool activo = false;
  int vida;
  const sf::Sprite &obtenerSprite() override;

public:
  Avion(std::string, sf::Vector2f posicion = {0, 0},
        sf::Vector2f velocidad = {5, 5}, int vida = 1000);
  const sf::Vector2f posicionSprite() override;
  const void moverImagen() override;
  const void moverImagen(sf::Vector2f) override;
  const bool rotarImagen(const float &) override;
  void apuntar(const sf::Vector2f, const sf::Vector2f) override;
  float obtenerRotacion() override;
  void cambiarPosicion(sf::Vector2f) override;
  void cambiarVelocidad(sf::Vector2f) override;
  int verVida() override;
  void modificarVida(int) override;
  void seguirObjetivo(sf::Vector2f, sf::Vector2f, sf::Vector2f) override;
  sf::Vector2f verVelocidad() override;
  sf::Vector2f tamanioTextura() override;
  sf::Vector2f tamanioSprite() override;
  sf::FloatRect limitesNave() const override;
  void modificarEstado(bool) override;
  void recibirDanio(int danio = 10) override;
  bool verEstado() override;
  std::string verRuta() override;
};
#endif // !AVION_H
