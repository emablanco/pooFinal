#include "base.h"
#include "nave.h"
#include <SFML/Graphics/CircleShape.hpp>
#include <SFML/Graphics/Color.hpp>
#include <SFML/Graphics/RenderWindow.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Text.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/View.hpp>
#include <SFML/System/Vector2.hpp>
#include <SFML/Window/Event.hpp>
#include <SFML/Window/Mouse.hpp>
#include <SFML/Window/VideoMode.hpp>
#include <cmath>
#include <string>
#include <vector>
Base::Base(sf::Texture *t)
    : ventana(new sf::RenderWindow(
          sf::VideoMode((float)t->getSize().x, (float)t->getSize().y), "Ema")) {

  // wallpapers
  wallpapers_tex = t;
  wallpapers_spr = new sf::Sprite;
  wallpapers_spr->setTexture(*wallpapers_tex);
  wallpapers_spr->setOrigin(wallpapers_tex->getSize().x / 2.f,
                            wallpapers_tex->getSize().y / 2.f);
  wallpapers_spr->setPosition(0, 0);
  // vosor
  visor = new sf::View;
  visor->setSize((float)t->getSize().x, (float)t->getSize().y);
  visor->setCenter(0, 0);

  // ventana
  ventana->setFramerateLimit(120);

  // evento
  evento1 = new sf::Event;
}

// DIBUJA LOS SPRITES
bool Base::dibujar() {
  ventana->clear(sf::Color::Red);
  ventana->setView(*visor);
  ventana->draw(*wallpapers_spr);
  return ventana->isOpen();
}
bool Base::dibujar(Nave *player1) {
  ventana->clear(sf::Color::Red);
  ventana->setView(*visor);
  ventana->draw(*wallpapers_spr);
  ventana->draw(*player1);
  ventana->display();
  return ventana->isOpen();
}
bool Base::dibujar(Nave *player, std::vector<Objetos *> &tiros,
                   std::vector<Nave *> &naves, std::vector<Objetos *> &tiros2,
                   std::vector<Objetos *> &chatarra) {
  ventana->clear(sf::Color::Red);
  ventana->setView(*visor);
  ventana->draw(*wallpapers_spr);
  for (size_t i = 0; i < chatarra.size(); i++) {
    ventana->draw(*chatarra[i]);
  }
  for (size_t i = 0; i < tiros.size(); i++) {
    ventana->draw(*tiros[i]);
  }
  for (size_t i = 0; i < naves.size(); i++) {
    ventana->draw(*naves[i]);
  }
  for (size_t i = 0; i < tiros2.size(); i++) {
    ventana->draw(*tiros2[i]);
  }
  ventana->draw(*player);
  ventana->display();
  return ventana->isOpen();
}

// DEVUEVE EL ESTADO DE LA VENTANA
bool Base::estadoVentan() {
  while (ventana->isOpen()) {
    while (ventana->pollEvent(*evento1)) {
      if (evento1->type == sf::Event::Closed) {
        ventana->close();
      }
    }
    return ventana->isOpen();
  }
  return ventana->isOpen();
}
// MOVER VISOR
bool Base::moverVisor(const sf::Vector2f &velocidad) {
  visor->move(velocidad);
  return true;
}
// POSICION DEL MOUSE EN LA ventana
sf::Vector2f Base::posicionMouse() {
  // Mouse::getPosition -> representa la posicon del mounse en la ventana
  return sf::Vector2f(sf::Mouse::getPosition(*ventana));
}
sf::Vector2f Base::posicionSprite(const sf::Vector2f &objeto) {
  return sf::Vector2f(ventana->mapCoordsToPixel(objeto));
}

sf::Vector2f Base::direccionNormalizada(sf::Vector2f player) {
  sf::Vector2i mouse = sf::Mouse::getPosition(*ventana);
  sf::Vector2i avion = ventana->mapCoordsToPixel(player);
  sf::Vector2f dir = sf::Vector2f(mouse - avion);
  float aux1 = std::sqrt(std::pow(dir.x, 2) + std::pow(dir.y, 2));
  float aux2 = std::sqrt(std::pow(dir.x, 2) + std::pow(dir.y, 2));
  sf::Vector2f dirN = {dir.x / aux1, dir.y / aux2};
  /**
    sf::Vector2f dir = sf::Vector2f(sf::Mouse::getPosition(*ventana) -
                                    ventana->mapCoordsToPixel(player));
sf::Vector2f dirN = sf::Vector2f(dir.x / std::sqrt(std::pow(dir.x, 2) +
std::pow(dir.y, 2)), dir.y / std::sqrt(std::pow(dir.x, 2) + std::pow(dir.y,
2)));
**/
  return dirN;
}
sf::Vector2f Base::direccionNormalizada(sf::Vector2f enemigo,
                                        sf::Vector2f avion) {
  sf::Vector2f dir = sf::Vector2f(enemigo - avion);
  float aux1 = std::sqrt(std::pow(dir.x, 2) + std::pow(dir.y, 2));
  float aux2 = std::sqrt(std::pow(dir.x, 2) + std::pow(dir.y, 2));
  sf::Vector2f dirN = {dir.x / aux1, dir.y / aux2};
  return dirN;
}
// DESTRUCTOR DE PUNTEROS

Base::~Base() {
  delete ventana;
  delete wallpapers_spr;
  delete wallpapers_tex;
  delete visor;
  delete evento1;
}
