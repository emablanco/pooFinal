#ifndef BASE_H
#define BASE_H

#include "balas.h"
#include "chatarra.h"
#include "nave.h"
#include "objetos.h"
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/CircleShape.hpp>
#include <SFML/Graphics/RenderWindow.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/View.hpp>
#include <SFML/System/Vector2.hpp>
#include <SFML/Window/Event.hpp>
#include <cmath>
#include <string>
#include <vector>
class Base {

private:
  sf::RenderWindow *ventana = nullptr;
  sf::Texture *wallpapers_tex = nullptr;
  sf::Sprite *wallpapers_spr = nullptr;
  sf::View *visor = nullptr;
  sf::Event *evento1 = nullptr;

public:
  Base(sf::Texture *);
  // DIBUJAR wallpapers_tex
  bool dibujar();
  // DIBIJAR PLAYER
  bool dibujar(Nave *);
  bool dibujar(Nave *, std::vector<Objetos *> &, std::vector<Nave *> &,
               std::vector<Objetos *> &, std::vector<Objetos *> &);
  // VER ESTADO VENTANA
  bool estadoVentan();
  // MOVER VISOR
  bool moverVisor(const sf::Vector2f &);
  // POSICION MOUSE
  sf::Vector2f posicionMouse();
  // POSICION SPRITE VENTANA
  sf::Vector2f posicionSprite(const sf::Vector2f &);
  const sf::Vector2f verResolucion();
  // VER EVENTO

  sf::Vector2f direccionNormalizada(sf::Vector2f);
  sf::Vector2f direccionNormalizada(sf::Vector2f, sf::Vector2f);
  ~Base();
};

#endif // !BASE_H
