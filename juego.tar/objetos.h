#ifndef OBJETOS_H
#define OBJETOS_H

#include "coliciones.h"
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/CircleShape.hpp>
#include <SFML/Graphics/Drawable.hpp>
#include <SFML/System/Vector2.hpp>
#include <cmath>
#include <string>

class Objetos : public sf::Drawable, public Coliciones {
private:
  //  sf::CircleShape circulo;
  //  virtual const sf::CircleShape obtenerDisparo() = 0;
  virtual const sf::Sprite &obtenerSprite() = 0;
  virtual sf::FloatRect limitesObjetos() const = 0;
  sf::Sprite spr;

public:
  Objetos();
  void draw(sf::RenderTarget &target, sf::RenderStates states) const override;

  void updateSprite();

  sf::FloatRect obtenerLimites() const override;
  virtual sf::Vector2f verPosicion() = 0;
  virtual void moverTiro() = 0;
  virtual bool verEstado() = 0;
  virtual void modificarEstado(bool) = 0;
  virtual void modificarAlpha(float) = 0;
};
#endif // !DEBUG OBJETOS_H
