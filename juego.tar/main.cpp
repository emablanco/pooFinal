#include "avion.h"
#include "balas.h"
#include "base.h"
#include "chatarra.h"
#include "nave.h"
#include "objetos.h"
#include <SFML/Graphics/Rect.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Text.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/Vertex.hpp>
#include <SFML/System/Vector2.hpp>
#include <SFML/Window/Keyboard.hpp>
#include <SFML/Window/Mouse.hpp>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <iterator>
#include <string>
#include <thread>
#include <utility>
#include <vector>

static sf::Vector2f resolucion = {1600, 900};
static sf::Vector2f velocidad = {5, 5};

int muertos = 10;

void destruirProjectil(sf::Vector2f, std::vector<Objetos *> &);

void eventoMouse(Base *, sf::Vector2f, int &, std::vector<Objetos *> &,
                 std::string);

void tecladoPlayer1(Base *, Nave *, const sf::Vector2f &, const sf::Vector2f &);

void crearEnemigo(std::string, std::vector<Nave *> &, sf::Vector2f);

void disparosEnemigos(Base *, std::vector<Objetos *> &, int &, int &,
                      sf::Vector2f, Nave *);

void comprobarColiciones(std::vector<Objetos *> &, std::vector<Nave *> &, int,
                         std::vector<Objetos *> &, std::string);

void comprobarColiciones(std::vector<Objetos *> &, Nave *, int);

void calcularDistanciaEnemigo(Nave *, Nave *, int);

void moverAvionesAutomaticamente(Base &, Nave *);

void destruirChatarra(std::vector<Objetos *> &chatarra, float);

int main(int argc, char *argv[]) {

  srand(time(NULL));
  int delay = 0;
  int delay2 = 0;
  int tiempo = rand() % (500) + 100;
  sf::Texture *wallpapers;
  wallpapers = new sf::Texture;
  wallpapers->loadFromFile("./imagen/wallpapers.jpg");
  resolucion = sf::Vector2f(wallpapers->getSize());
  Base juego(wallpapers);
  int n = rand() % (12) + 1;
  std::string ruta = "./imagen/avion1/" + std::to_string(n) + ".png";
  sf::Vector2f escalarImagen = {0.3, 0.3};

  Nave *avion = new Avion(ruta, {0, 0}, {5, 5}, 10000);

  std::vector<Objetos *> projectiles;  // Almacenar proyectiles
  std::vector<Objetos *> projectiles2; // Almacenar proyectiles
  std::vector<Objetos *> chatarra;     // Almacenar chatarra
  std::vector<Nave *> enemigos;

  std::string r_cha = "./imagen/pelota.png";

  while (juego.estadoVentan()) {

    while (enemigos.size() <= muertos / 10) {
      int n1 = rand() % (12) + 1;
      std::string ruta2 = "./imagen/avion1/" + std::to_string(n1) + ".png";
      crearEnemigo(ruta2, enemigos, avion->posicionSprite());
    }
    avion->updateSprite();

    for (size_t i = 0; i < enemigos.size(); i++) {
      calcularDistanciaEnemigo(enemigos[i], avion, 800);
      if (enemigos[i]->verEstado()) {
        sf::Vector2f dir = juego.direccionNormalizada(
            avion->posicionSprite(), enemigos[i]->posicionSprite());
        enemigos[i]->seguirObjetivo(dir, avion->posicionSprite(),
                                    avion->tamanioSprite());
        enemigos[i]->apuntar(
            juego.posicionSprite(avion->posicionSprite()),
            juego.posicionSprite(enemigos[i]->posicionSprite()));
        disparosEnemigos(&juego, projectiles2, delay2, tiempo,
                         avion->posicionSprite(), enemigos[i]);
      }
      enemigos[i]->updateSprite();
    }

    if (avion->verVida() > 0) {
      tecladoPlayer1(&juego, avion, resolucion, velocidad);
      avion->apuntar(juego.posicionMouse(),
                     juego.posicionSprite(avion->posicionSprite()));
      eventoMouse(&juego, avion->posicionSprite(), delay, projectiles, ruta);
    }

    destruirProjectil(resolucion, projectiles);
    destruirProjectil(resolucion, projectiles2);
    destruirChatarra(chatarra, 0.1);

    comprobarColiciones(projectiles, enemigos, 25, chatarra, r_cha);
    comprobarColiciones(projectiles2, avion, 25);

    juego.dibujar(avion, projectiles, enemigos, projectiles2, chatarra);
    std::cout << "Enemigos: " << enemigos.size() << "\n";
  }

  delete avion;
  for (size_t i = 0; i < projectiles.size(); i++)
    delete projectiles[i];

  for (size_t i = 0; i < enemigos.size(); i++)
    delete enemigos[i];

  for (size_t i = 0; i < projectiles2.size(); i++)
    delete projectiles2[i];

  return 0;
}

void comprobarColiciones(std::vector<Objetos *> &disparos, Nave *avion,
                         int restart) {
  for (size_t i = 0; i < disparos.size(); i++) {
    if (disparos[i]->verEstado() and disparos[i]->estaColicionando(*avion)) {
      avion->modificarVida(avion->verVida() - restart);
      std::cout << "Vida: " << avion->verVida() << "\n";
      disparos[i]->modificarEstado(false);
      disparos.erase(
          std::remove_if(disparos.begin(), disparos.end(),
                         [](Objetos *b) -> bool { return !b->verEstado(); }),
          disparos.end());
    }
  }
}

void destruirChatarra(std::vector<Objetos *> &chatarra, float alpha) {
  for (size_t i = 0; i < chatarra.size(); i++) {
    chatarra[i]->modificarAlpha(alpha);
    chatarra[i]->updateSprite();
  }
  chatarra.erase(
      std::remove_if(chatarra.begin(), chatarra.end(),
                     [](Objetos *b) -> bool { return !b->verEstado(); }),
      chatarra.end());
}

void comprobarColiciones(std::vector<Objetos *> &disparos,
                         std::vector<Nave *> &enemigos, int restart,
                         std::vector<Objetos *> &chatarra, std::string ruta) {
  for (size_t i = 0; i < disparos.size(); i++) {
    for (size_t e = 0; e < enemigos.size(); e++) {
      if (disparos[i]->verEstado() and
          disparos[i]->estaColicionando(*enemigos[e])) {
        // disparos[i]->modificarEstado(false);
        enemigos[e]->modificarVida(enemigos[e]->verVida() - restart);
        enemigos[e]->modificarEstado(true);
        disparos[i]->modificarEstado(false);

        if (enemigos[e]->verVida() < 0) {
          ++muertos;
          chatarra.emplace_back(
              new Chatarra(ruta, enemigos[e]->posicionSprite()));
        }
      }
      enemigos.erase(
          std::remove_if(enemigos.begin(), enemigos.end(),
                         [](Nave *n) -> bool { return n->verVida() < 0; }),
          enemigos.end());
      disparos.erase(
          std::remove_if(disparos.begin(), disparos.end(),
                         [](Objetos *b) -> bool { return !b->verEstado(); }),
          disparos.end());
    }
  }
}

void crearEnemigo(std::string ruta, std::vector<Nave *> &enemigos,
                  sf::Vector2f posicion_avion) {
  // 1080 / 2 = 540, 740 / 2 = 370
  sf::IntRect rec_posicion(posicion_avion.x - resolucion.x / 2,
                           posicion_avion.y - resolucion.y / 2, resolucion.x,
                           resolucion.y);
  sf::Vector2f posicion;
  do {
    posicion.x = rand() % (int)(resolucion.x * 2) - resolucion.x;
    posicion.y = rand() % (int)(resolucion.y * 2) - resolucion.y;
  } while (rec_posicion.contains(posicion.x, posicion.y));
  enemigos.emplace_back(new Avion(ruta, posicion, {3, 3}, 100));
}
void destruirProjectil(sf::Vector2f window,
                       std::vector<Objetos *> &projectiles) {
  // Mover y actualizar proyectiles
  for (auto &projectile : projectiles) {
    projectile->moverTiro();
    projectile->updateSprite();
    sf::Vector2f posicion = projectile->verPosicion();
    // Verificar si el proyectil salió de la ventana
    if (posicion.x < 0 or posicion.x > window.x or posicion.y < 0 or
        posicion.y > window.y) {
      projectiles.erase(
          std::remove_if(projectiles.begin(), projectiles.end(),
                         [window](Objetos *p) -> bool {
                           return p->verPosicion().x < -window.x or
                                  p->verPosicion().x > window.x or
                                  p->verPosicion().y < -window.y or
                                  p->verPosicion().y > window.y;
                         }),
          projectiles.end());
    }
  }
}

void disparosEnemigos(Base *juego, std::vector<Objetos *> &projectiles,
                      int &delay2, int &tiempo, sf::Vector2f enemigo,
                      Nave *avion) {
  if (delay2 >= tiempo) {
    projectiles.emplace_back(new Balas(
        avion->verRuta(), avion->posicionSprite(),
        juego->direccionNormalizada(enemigo, avion->posicionSprite()), 3.0f));
    delay2 = 0;
    tiempo = rand() % (500) + 10;
  }
  ++delay2;
}

void eventoMouse(Base *juego, sf::Vector2f posicion_avion, int &delay,
                 std::vector<Objetos *> &projectiles, std::string ruta) {
  if (sf::Mouse::isButtonPressed(sf::Mouse::Left) and delay >= 15) {
    projectiles.emplace_back(
        new Balas(ruta, posicion_avion,
                  juego->direccionNormalizada(posicion_avion), 9.0f));
    delay = 0;
  }
  ++delay;
}

void tecladoPlayer1(Base *juego, Nave *avion, const sf::Vector2f &resolucion,
                    const sf::Vector2f &velocidad) {
  sf::Vector2f mover;
  if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) and
      avion->posicionSprite().y > -(resolucion.y / 2.f)) {
    mover = {0, velocidad.y * -1};
    avion->moverImagen(mover);
    juego->moverVisor(mover);
  }
  if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) and
      avion->posicionSprite().y < resolucion.y / 2.f) {
    mover = {0, velocidad.y};
    avion->moverImagen(mover);
    juego->moverVisor(mover);
  }
  if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left) and
      avion->posicionSprite().x > -(resolucion.x / 2.f)) {
    mover = {velocidad.x * -1, 0};
    avion->moverImagen(mover);
    juego->moverVisor(mover);
  }
  if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right) and
      avion->posicionSprite().x < resolucion.x / 2.f) {
    mover = {velocidad.x, 0};
    avion->moverImagen(mover);
    juego->moverVisor(mover);
  }
}

void calcularDistanciaEnemigo(Nave *malo, Nave *bueno, int distancia) {
  sf::Vector2f dir = bueno->posicionSprite() - malo->posicionSprite();
  if (std::abs(dir.x) + std::abs(dir.y) <= distancia) {
    malo->modificarEstado(true);
  }
}
